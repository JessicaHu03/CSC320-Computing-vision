# CSC320 Spring 2023
# Assignment 4
# (c) Olga (Ge Ya) Xu, Kyros Kutulakos
#
# UPLOADING THIS CODE TO GITHUB OR OTHER CODE-SHARING SITES IS
# STRICTLY FORBIDDEN.
#
# DISTRIBUTION OF THIS CODE ANY FORM (ELECTRONIC OR OTHERWISE,
# AS-IS, MODIFIED OR IN PART), WITHOUT PRIOR WRITTEN AUTHORIZATION
# BY KYROS KUTULAKOS IS STRICTLY FORBIDDEN. VIOLATION OF THIS
# POLICY WILL BE CONSIDERED AN ACT OF ACADEMIC DISHONESTY.
#
# THE ABOVE STATEMENTS MUST ACCOMPANY ALL VERSIONS OF THIS CODE,
# WHETHER ORIGINAL OR MODIFIED.
#
# DO NOT MODIFY THIS FILE ANYWHERE EXCEPT WHERE INDICATED
#

# Import basic packages.
from typing import List, Union, Tuple, Dict
import numpy as np

#
# Basic numpy configuration
#

# Set random seed.
np.random.seed(seed=1006836480)
# Ignore division-by-zero warning.
np.seterr(divide='ignore', invalid='ignore')


def propagation_and_random_search(
        source_patches: np.ndarray,
        target_patches: np.ndarray,
        f: np.ndarray,
        alpha: float,
        w: int,
        propagation_enabled: bool,
        random_enabled: bool,
        odd_iteration: bool,
        best_D: Union[np.ndarray, None] = None,
        global_vars: Union[Dict, None] = None) -> \
        Tuple[np.ndarray, np.ndarray, Dict]:
    """
    Basic PatchMatch loop.

    This function implements the basic loop of the PatchMatch algorithm, as
    explained in Section 3.2 of the paper. The function takes an NNF f as
    input, performs propagation and random search, and returns an updated NNF.

    Args:
        source_patches:
            A numpy matrix holding the patches of the color source image,
              as computed by the make_patch_matrix() function in this module.
              For an NxM source image and patches of width P, the matrix has
              dimensions NxMxCx(P^2) where C is the number of color channels
              and P^2 is the total number of pixels in the patch.  For
              your purposes, you may assume that source_patches[i,j,c,:]
              gives you the list of intensities for color channel c of
              all pixels in the patch centered at pixel [i,j]. Note that patches
              that go beyond the image border will contain NaN values for
              all patch pixels that fall outside the source image.
        target_patches:
            The matrix holding the patches of the target image, represented
              exactly like the source_patches argument.
        f:
            The current nearest-neighbour field.
        alpha:
            Algorithm parameter, as explained in Section 3 and Eq.(1).
        w:
            Algorithm parameter, as explained in Section 3 and Eq.(1).
        propagation_enabled:
            If false, propagation should be performed. Use this flag for
              debugging purposes, to see how your
              algorithm performs with (or without) this step.
        random_enabled:
            If false, random search should be performed. Use this flag for
              debugging purposes, to see how your
              algorithm performs with (or without) this step.
        odd_iteration:
            True if and only if this is an odd-numbered iteration.
              As explained in Section 3.2 of the paper, the algorithm
              behaves differently in odd and even iterations and this
              parameter controls this behavior.
        best_D:
            And NxM matrix whose element [i,j] is the similarity score between
              patch [i,j] in the source and its best-matching patch in the
              target. Use this matrix to check if you have found a better
              match to [i,j] in the current PatchMatch iteration.
        global_vars:
            (optional) if you want your function to use any global variables,
              return them in this argument, and they will be stored in the
              PatchMatch data structure.

    Returns:
        A tuple containing (1) the updated NNF, (2) the updated similarity
          scores for the best-matching patches in the target, and (3)
          optionally, if you want your function to use any global variables,
          return them in this argument, and they will be stored in the
          PatchMatch data structure.
    """

    #############################################
    ###  PLACE YOUR CODE BETWEEN THESE LINES  ###
    #############################################

    new_f = f.copy()
    # new_D = best_D.copy()

    Ns, Ms, Cs, Ps = source_patches.shape
    Nt, Mt, Ct, Pt = target_patches.shape

    max_y_s, max_x_s = Ns - 1, Ms - 1
    max_y_t, max_x_t = Nt - 1, Mt - 1

    # determine the order of propagation
    if odd_iteration:
        rows, cols = list(range(0, source_patches.shape[0])), list(range(0, source_patches.shape[1]))
        dir = 1
    else:
        rows, cols = list(reversed(range(0, source_patches.shape[0]))), list(reversed(range(0, source_patches.shape[1])))
        dir = -1

    # initialize best_D if not given
    if best_D is None:
        # find neighbors on target
        neighbors = make_coordinates_matrix(source_patches.shape[:2]) + f.astype(np.int)
        # bound the interval of neighbors to [0, max_y_t] and [0, max_x_t]
        neighbors = np.clip(neighbors, [0, 0], [max_y_t, max_x_t])
        # find corresponding target patches
        neighbors = target_patches[neighbors[:, :, 0], neighbors[:, :, 1]]

        dist = neighbors - source_patches
        total = np.sum(np.isnan(dist), (2, 3)) / Cs
        # best_D = total # squared dist / # pixels
        best_D = np.nansum(dist ** 2, (2, 3)) / (Ps - total)

    for i in rows:
        for j in cols:
            
            # propagation
            if not propagation_enabled:

                curr_j = j - dir
                curr_i = i - dir

                if 0 <= curr_j <= max_x_s:
                    # find the position of the neighbor
                    n_pos = (new_f[i, j - dir] + [i, j]).astype(int)
                    nei_pos = np.clip(n_pos, [0, 0], [max_y_t, max_x_t])
                    tar_nei = target_patches[nei_pos[0], nei_pos[1]]
                    dist = source_patches[i, j] - tar_nei
                    total = np.sum(np.isnan(dist) / Cs)
                    new_D = np.nansum(dist ** 2) / (Ps - total)

                    if best_D[i, j] > new_D:
                        best_D[i, j] = new_D
                        new_f[i, j] = nei_pos - [i, j]

                if 0 <= curr_i <= max_y_s:
                    # find the position of the neighbor
                    n_pos = (new_f[i - dir, j] + [i, j]).astype(int)
                    nei_pos = np.clip(n_pos, [0, 0], [max_y_t, max_x_t])
                    tar_nei = target_patches[nei_pos[0], nei_pos[1]]
                    dist = source_patches[i, j] - tar_nei
                    total = np.sum(np.isnan(dist) / Cs)
                    new_D = np.nansum(dist ** 2) / (Ps -  total)

                    if best_D[i, j] > new_D:
                        best_D[i, j] = new_D
                        new_f[i, j] = nei_pos - [i, j]

            # random search
            if not random_enabled:

                # stop itr if alpha^itr > w
                num_itrs = np.ceil(np.log(1 / w) / np.log(alpha)).astype(int)

                # search radius
                radius = w * (alpha ** np.arange(num_itrs))

                # R_i
                size = radius.shape[0]
                r = np.random.uniform(-1, 1, size=(size, 2))

                # u
                u = (new_f[i, j] + radius[:, None] * r).astype(int)
                
                # bound the interval to [0, max_y_t] and [0, max_x_t]
                u_pos = np.clip(u + [i, j], [0, 0], [max_y_t, max_x_t])
                nei_pat = target_patches[u_pos[:, 0], u_pos[:, 1]]

                dist = nei_pat - source_patches[i, j]

                total = np.sum(np.isnan(dist), (1, 2)) / Cs
                new_D = np.nansum(dist ** 2, (1, 2)) / (Ps - total)

                f_wanted = np.argmin(new_D)
                d_wanted = new_D[f_wanted]

                if best_D[i, j] > d_wanted:
                    best_D[i, j] = d_wanted
                    new_f[i, j] = u_pos[f_wanted] - [i, j]

    #############################################

    return new_f, best_D, global_vars


def reconstruct_source_from_target(target: np.ndarray,
                                   f: np.ndarray) -> np.ndarray:
    """
    Reconstruct a source image using pixels from a target image.

    This function uses a computed NNF f(j,i) to reconstruct the source image
    using pixels from the target image.  To reconstruct the source, the
    function copies to pixel (j,i) of the source the color of
    pixel (j,i)+f(j,i) of the target.

    The goal of this routine is to demonstrate the quality of the
    computed NNF f. Specifically, if patch (j,i) + f(j,i) in the target image
    is indeed very similar to patch (j,i) in the source, then copying the
    color of target pixel (j,i) + f(j,i) to the source pixel (j,i) should not
    dir the source image appreciably. If the NNF is not very high
    quality, however, the reconstruction of source image
    will not be very good.

    You should use matrix/vector operations to avoid looping over pixels,
    as this would be very inefficient.

    Args:
        target:
            The target image that was used as input to PatchMatch.
        f:
            A nearest-neighbor field the algorithm computed.
    Returns:
        An openCV image that has the same shape as the source image.
    """
    rec_source = None

    #############################################
    ###  PLACE YOUR CODE BETWEEN THESE LINES  ###
    #############################################
    rec_source = np.zeros_like(target)
    # rec_source = target + f

    # matrix (j,i)+f(j, i)
    source_coord = make_coordinates_matrix(f.shape[:2])
    target_coord = (source_coord + f).astype(np.int)

    # inbound
    max_y, max_x = np.array(f.shape[:2]) - 1
    in_bound = np.clip(target_coord, [0, 0], [max_y, max_x]).astype(np.int)

    # reconstruct
    rec_source = target[in_bound[:, :, 0], in_bound[:, :, 1]]
    #############################################

    return rec_source


def make_patch_matrix(im: np.ndarray, patch_size: int) -> np.ndarray:
    """
    PatchMatch helper function.

    This function is called by the initialized_algorithm() method of the
    PatchMatch class. It takes an NxM image with C color channels and a patch
    size P and returns a matrix of size NxMxCxP^2 that contains, for each
    pixel [i,j] in the image, the pixels in the patch centered at [i,j].

    You should study this function very carefully to understand precisely
    how pixel data are organized, and how patches that extend beyond
    the image border are handled.

    Args:
        im:
            A image of size NxM.
        patch_size:
            The patch size.

    Returns:
        A numpy matrix that holds all patches in the image in vectorized form.
    """
    phalf = patch_size // 2
    # create an image that is padded with patch_size/2 pixels on all sides
    # whose values are NaN outside the original image
    padded_shape = im.shape[0] + patch_size - 1, \
                   im.shape[1] + patch_size - 1, \
        im.shape[2]
    padded_im = np.zeros(padded_shape) * np.NaN
    padded_im[phalf:(im.shape[0] + phalf), phalf:(im.shape[1] + phalf), :] = im

    # Now create the matrix that will hold the vectorized patch of each pixel.
    # If the original image had NxM pixels, this matrix will have
    # NxMx(patch_size*patch_size) pixels
    patch_matrix_shape = im.shape[0], im.shape[1], im.shape[2], patch_size ** 2
    patch_matrix = np.zeros(patch_matrix_shape) * np.NaN
    for i in range(patch_size):
        for j in range(patch_size):
            patch_matrix[:, :, :, i * patch_size + j] = \
                padded_im[i:(i + im.shape[0]), j:(j + im.shape[1]), :]

    return patch_matrix


def make_coordinates_matrix(im_shape: Tuple, step: int = 1) -> np.ndarray:
    """
    PatchMatch helper function.

    This function returns a matrix g of size (im_shape[0] j im_shape[1] j 2)
    such that g(i,j) = [i,j].

    Pay attention to this function as it shows how to perform these types
    of operations in a vectorized manner, without resorting to loops.

    Args:
        im_shape:
            A tuple that specifies the size of the input images.
        step:
            (optional) If specified, the function returns a matrix that is
              step times smaller than the full image in each dimension.
    Returns:
        A numpy matrix holding the function g.
    """
    range_x = np.arange(0, im_shape[1], step)
    range_y = np.arange(0, im_shape[0], step)
    axis_x = np.repeat(range_x[np.newaxis, ...], len(range_y), axis=0)
    axis_y = np.repeat(range_y[..., np.newaxis], len(range_x), axis=1)

    return np.dstack((axis_y, axis_x))
